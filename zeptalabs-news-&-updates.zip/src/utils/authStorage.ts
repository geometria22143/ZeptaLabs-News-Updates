import emailjs from '@emailjs/browser';
import { StoredUser, UserProfile } from '../types/auth';

const USERS_KEY = 'zeptalabs_users';
const CURRENT_USER_KEY = 'zeptalabs_current_user';

export const EMAILJS_CONFIG = {
  serviceId: 'service_wotox2121',
  templateId: 'template_2f2zlo1',
  publicKey: '3KhMYEXg6XYbAUOyW',
};

export function getStoredUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveUser(user: StoredUser): void {
  const users = getStoredUsers().filter(
    (u) => u.email.toLowerCase() !== user.email.toLowerCase()
  );
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function findUserByEmail(email: string): StoredUser | undefined {
  const users = getStoredUsers();
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export function getCurrentUser(): UserProfile | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user: UserProfile | null): void {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

export async function sendOtpEmail(params: {
  name: string;
  email: string;
  passcode: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const now = new Date();
    const timeFormatted = now.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const templateParams = {
      name: params.name,
      email: params.email,
      passcode: params.passcode,
      time: timeFormatted,
    };

    const response = await emailjs.send(
      EMAILJS_CONFIG.serviceId,
      EMAILJS_CONFIG.templateId,
      templateParams,
      EMAILJS_CONFIG.publicKey
    );

    if (response.status === 200) {
      return { success: true };
    }
    return { success: false, error: `EmailJS responded with status: ${response.status}` };
  } catch (err: unknown) {
    const errorMsg =
      err instanceof Error
        ? err.message
        : typeof err === 'object' && err !== null && 'text' in err
        ? String((err as { text: unknown }).text)
        : 'Failed to send OTP email.';
    return { success: false, error: errorMsg };
  }
}
