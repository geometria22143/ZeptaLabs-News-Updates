export interface UserProfile {
  name: string;
  email: string;
  avatarUrl: string;
  isAdmin?: boolean;
  hideEmail?: boolean;
}

export interface StoredUser {
  name: string;
  email: string;
  password: string;
  avatarUrl: string;
  createdAt: string;
  isAdmin?: boolean;
  hideEmail?: boolean;
}
