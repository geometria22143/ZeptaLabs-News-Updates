import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, LogOut, User, PlusCircle } from 'lucide-react';
import { UserProfile } from '../types/auth';

interface NavbarProps {
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenShareModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenAuth,
  onLogout,
  onOpenShareModal,
}) => {
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [logoLoadError, setLogoLoadError] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#' },
    { label: 'News', href: '#news' },
    { label: 'updates', href: '#updates' },
    { label: 'About', href: '#about' },
    { label: 'Contact Us', href: '#contact' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Left: Brand Logo linking to logo.png */}
          <div className="flex items-center">
            <motion.a
              href="logo.png"
              target="_blank"
              rel="noopener noreferrer"
              title="ZeptaLabs Logo"
              className="flex items-center gap-2 group cursor-pointer"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            >
              {!logoLoadError ? (
                <img
                  src="logo.png"
                  alt="ZeptaLabs Logo"
                  onError={() => setLogoLoadError(true)}
                  className="h-8 w-auto max-w-[120px] object-contain transition-transform duration-200"
                />
              ) : (
                <div className="h-8 w-8 bg-black text-white flex items-center justify-center font-bold text-xs uppercase tracking-wider">
                  ZL
                </div>
              )}
              <span className="font-semibold text-base sm:text-lg tracking-tight text-black select-none">
                ZeptaLabs{' '}
                <span className="font-normal text-neutral-500 text-sm">
                  News&amp;Updates
                </span>
              </span>
            </motion.a>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 relative">
            {navLinks.map((link) => {
              const isHovered = hoveredNav === link.label;

              return (
                <a
                  key={link.label}
                  href={link.href}
                  onMouseEnter={() => setHoveredNav(link.label)}
                  onMouseLeave={() => setHoveredNav(null)}
                  className="relative px-3.5 py-2 text-sm font-medium text-neutral-600 hover:text-black transition-colors focus:outline-none"
                >
                  <span className="relative z-10">{link.label}</span>

                  {/* Smooth Hover Pill Animation */}
                  {isHovered && (
                    <motion.div
                      layoutId="navHoverPill"
                      className="absolute inset-0 bg-neutral-100 z-0"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Right: User Account Profile / Login Button */}
          <div className="flex items-center space-x-3">
            {currentUser ? (
              /* User is logged in: show profile and action buttons */
              <div className="hidden sm:flex items-center gap-3 pl-2 border-l border-neutral-200">
                {/* Admin "Share An Update/News" Button */}
                {currentUser.isAdmin && (
                  <motion.button
                    type="button"
                    onClick={onOpenShareModal}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-black text-white hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Share An Update/News</span>
                  </motion.button>
                )}

                {/* Profile Display: Picture and Name (email is hidden as requested) */}
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full border border-black overflow-hidden bg-neutral-100 flex items-center justify-center shrink-0">
                    {currentUser.avatarUrl ? (
                      <img
                        src={currentUser.avatarUrl}
                        alt={currentUser.name}
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).src = 'logo.png';
                        }}
                      />
                    ) : (
                      <User className="w-4 h-4 text-neutral-600" />
                    )}
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs font-bold text-black max-w-[140px] truncate leading-tight">
                      {currentUser.name}
                    </span>
                    {!currentUser.hideEmail && !currentUser.isAdmin && (
                      <span className="text-[10px] text-neutral-500 font-mono truncate max-w-[140px]">
                        {currentUser.email}
                      </span>
                    )}
                  </div>
                </div>

                {/* Logout Button */}
                <motion.button
                  type="button"
                  onClick={onLogout}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-neutral-300 hover:border-black text-black hover:bg-neutral-100 transition-colors cursor-pointer"
                  title="Logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </motion.button>
              </div>
            ) : (
              /* User not logged in: show black Login / Signup button */
              <motion.button
                type="button"
                onClick={onOpenAuth}
                whileHover={{ scale: 1.04, y: -1 }}
                whileTap={{ scale: 0.96 }}
                transition={{ type: 'spring', stiffness: 450, damping: 25 }}
                className="hidden sm:inline-flex items-center gap-2 bg-black text-white text-sm font-medium px-4 py-2 hover:bg-neutral-800 transition-colors cursor-pointer group shadow-xs"
              >
                <span>Login / Signup</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
              </motion.button>
            )}

            {/* Mobile Menu Hamburger */}
            <motion.button
              type="button"
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-black hover:bg-neutral-100 transition-colors border border-neutral-200"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="md:hidden border-t border-neutral-200 bg-white overflow-hidden px-4 pt-3 pb-5 space-y-2 shadow-md"
          >
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3.5 py-2 text-sm font-medium text-neutral-700 hover:text-black hover:bg-neutral-100 transition-colors"
              >
                {link.label}
              </a>
            ))}

            <div className="pt-3 border-t border-neutral-200 sm:hidden">
              {currentUser ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 px-3 py-2 bg-neutral-50 border border-neutral-200">
                    <div className="w-8 h-8 rounded-full border border-black overflow-hidden bg-neutral-100 shrink-0 flex items-center justify-center">
                      {currentUser.avatarUrl ? (
                        <img
                          src={currentUser.avatarUrl}
                          alt={currentUser.name}
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src = 'logo.png';
                          }}
                        />
                      ) : (
                        <User className="w-4 h-4 text-neutral-600" />
                      )}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-black">
                        {currentUser.name}
                      </span>
                    </div>
                  </div>

                  {currentUser.isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenShareModal();
                      }}
                      className="w-full bg-black text-white text-xs font-semibold px-4 py-2 flex items-center justify-center gap-1.5 hover:bg-neutral-800 transition-colors"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>Share An Update/News</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full border border-black text-black text-sm font-medium px-4 py-2 flex items-center justify-center gap-2 hover:bg-neutral-100 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenAuth();
                  }}
                  className="w-full bg-black text-white text-sm font-medium px-4 py-2.5 flex items-center justify-center gap-2 hover:bg-neutral-800 transition-colors"
                >
                  <span>Login / Signup</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};
