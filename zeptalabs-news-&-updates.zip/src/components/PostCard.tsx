import React, { useState } from 'react';
import {
  Heart,
  MessageSquare,
  Share2,
  Download,
  Package,
  FileText,
  Send,
  Check,
  User,
} from 'lucide-react';
import { PostItem } from '../types/post';
import {
  togglePostLike,
  incrementPostShare,
  addCommentToPost,
  toggleCommentLike,
  getClientSessionId,
} from '../utils/postStorage';

interface PostCardProps {
  post: PostItem;
  onPostUpdated: () => void;
  currentUser?: { name: string; avatarUrl?: string } | null;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  onPostUpdated,
  currentUser,
}) => {
  const [showComments, setShowComments] = useState(false);
  const [newCommentText, setNewCommentText] = useState('');
  const [commenterName, setCommenterName] = useState(currentUser?.name || '');
  const [copiedLink, setCopiedLink] = useState(false);

  const clientId = getClientSessionId();
  const isPostLiked = (post.likedBy || []).includes(clientId);

  const handleLike = async () => {
    await togglePostLike(post.id);
    onPostUpdated();
  };

  const handleShare = async () => {
    await incrementPostShare(post.id);
    onPostUpdated();

    // Copy current URL or post anchor
    try {
      const url = `${window.location.origin}#${post.id}`;
      await navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const author = currentUser?.name || commenterName.trim() || 'Visitor';
    const avatar = currentUser?.avatarUrl || '';

    await addCommentToPost(post.id, author, newCommentText, avatar);
    setNewCommentText('');
    onPostUpdated();
  };

  const handleCommentLike = async (commentId: string) => {
    await toggleCommentLike(post.id, commentId);
    onPostUpdated();
  };

  return (
    <article
      id={post.id}
      className="border border-neutral-200 bg-white p-5 sm:p-7 transition-colors hover:border-neutral-400"
    >
      {/* Post Header */}
      <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-neutral-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full border border-neutral-300 overflow-hidden bg-neutral-100 flex items-center justify-center shrink-0">
            {post.authorAvatar ? (
              <img
                src={post.authorAvatar}
                alt={post.authorName}
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = 'logo.png';
                }}
              />
            ) : (
              <User className="w-5 h-5 text-neutral-500" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-black">
                {post.authorName}
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 bg-black text-white">
                Official
              </span>
            </div>
            <span className="text-xs text-neutral-400">{post.createdAt}</span>
          </div>
        </div>

        <span className="text-xs font-semibold px-2 py-1 bg-neutral-100 border border-neutral-200 text-neutral-700 uppercase">
          {post.category}
        </span>
      </div>

      {/* Post Title */}
      <h3 className="text-xl sm:text-2xl font-bold text-black mb-3 leading-snug">
        {post.title}
      </h3>

      {/* Post Description */}
      {post.description && (
        <div className="text-neutral-700 text-sm sm:text-base leading-relaxed mb-4 whitespace-pre-line">
          {post.description}
        </div>
      )}

      {/* Media / File Attachment */}
      {post.attachment && (
        <div className="mb-5 overflow-hidden border border-neutral-200 bg-neutral-50">
          {post.attachment.type === 'image' && (
            <img
              src={post.attachment.dataUrl}
              alt={post.attachment.name}
              className="w-full max-h-[460px] object-cover"
            />
          )}

          {post.attachment.type === 'video' && (
            <video
              src={post.attachment.dataUrl}
              controls
              className="w-full max-h-[460px] bg-black"
            />
          )}

          {(post.attachment.type === 'apk' || post.attachment.type === 'file') && (
            <div className="p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 overflow-hidden">
                <div className="p-2.5 bg-neutral-200 text-black shrink-0">
                  {post.attachment.type === 'apk' ? (
                    <Package className="w-6 h-6" />
                  ) : (
                    <FileText className="w-6 h-6" />
                  )}
                </div>
                <div className="overflow-hidden">
                  <p className="text-sm font-bold text-black truncate">
                    {post.attachment.name}
                  </p>
                  <p className="text-xs text-neutral-500">
                    {post.attachment.sizeFormatted} •{' '}
                    {post.attachment.type === 'apk'
                      ? 'Android Package File'
                      : 'File Attachment'}
                  </p>
                </div>
              </div>

              <a
                href={post.attachment.dataUrl}
                download={post.attachment.name}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </a>
            </div>
          )}
        </div>
      )}

      {/* Actions Bar: Likes, Comments, Shares */}
      <div className="flex items-center justify-between pt-3 border-t border-neutral-200 text-xs text-neutral-600">
        <div className="flex items-center space-x-6">
          {/* Like Button & Count */}
          <button
            type="button"
            onClick={handleLike}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
              isPostLiked ? 'text-black font-bold' : 'hover:text-black'
            }`}
          >
            <Heart
              className={`w-4 h-4 ${
                isPostLiked ? 'fill-black text-black' : ''
              }`}
            />
            <span>{post.likes || 0} Likes</span>
          </button>

          {/* Comment Button & Count */}
          <button
            type="button"
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1.5 hover:text-black transition-colors cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>{(post.comments || []).length} Comments</span>
          </button>
        </div>

        {/* Share Button & Count */}
        <div className="relative">
          <button
            type="button"
            onClick={handleShare}
            className="flex items-center gap-1.5 hover:text-black transition-colors cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>{post.shares || 0} Shares</span>
          </button>

          {copiedLink && (
            <span className="absolute right-0 -top-8 px-2 py-1 bg-black text-white text-[10px] flex items-center gap-1 shadow-md whitespace-nowrap">
              <Check className="w-3 h-3" /> Link copied!
            </span>
          )}
        </div>
      </div>

      {/* COMMENTS SECTION */}
      {showComments && (
        <div className="mt-5 pt-4 border-t border-neutral-100 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
            Comments ({(post.comments || []).length})
          </h4>

          {/* Add Comment Form */}
          <form onSubmit={handleAddComment} className="space-y-2">
            {!currentUser && (
              <input
                type="text"
                value={commenterName}
                onChange={(e) => setCommenterName(e.target.value)}
                placeholder="Your Name (Optional)"
                className="w-full px-3 py-1.5 border border-neutral-300 text-xs text-black focus:outline-none focus:border-black"
              />
            )}
            <div className="flex gap-2">
              <input
                type="text"
                required
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 px-3 py-2 border border-neutral-300 text-xs text-black focus:outline-none focus:border-black"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-black text-white text-xs font-semibold hover:bg-neutral-800 transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
              >
                <span>Post</span>
                <Send className="w-3 h-3" />
              </button>
            </div>
          </form>

          {/* Comments List */}
          {(post.comments || []).length > 0 ? (
            <div className="space-y-3 pt-2">
              {post.comments.map((comment) => {
                const isCommentLiked = (comment.likedBy || []).includes(clientId);

                return (
                  <div
                    key={comment.id}
                    className="p-3 bg-neutral-50 border border-neutral-200 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-neutral-500">
                      <span className="font-bold text-black">
                        {comment.authorName}
                      </span>
                      <span className="text-[10px]">{comment.createdAt}</span>
                    </div>

                    <p className="text-neutral-800 text-xs leading-normal">
                      {comment.content}
                    </p>

                    {/* Comment Like System */}
                    <div className="pt-1 flex items-center justify-end">
                      <button
                        type="button"
                        onClick={() => handleCommentLike(comment.id)}
                        className={`flex items-center gap-1 text-[11px] transition-colors cursor-pointer ${
                          isCommentLiked
                            ? 'text-black font-bold'
                            : 'text-neutral-500 hover:text-black'
                        }`}
                      >
                        <Heart
                          className={`w-3 h-3 ${
                            isCommentLiked ? 'fill-black text-black' : ''
                          }`}
                        />
                        <span>{comment.likes || 0} Likes</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-neutral-400 italic py-2">
              No comments yet. Be the first to comment!
            </p>
          )}
        </div>
      )}
    </article>
  );
};
