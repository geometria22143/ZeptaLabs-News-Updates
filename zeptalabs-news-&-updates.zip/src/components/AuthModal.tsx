import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  ArrowRight,
  Upload,
  User,
  Loader2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { UserProfile } from '../types/auth';
import {
  findUserByEmail,
  saveUser,
  sendOtpEmail,
} from '../utils/authStorage';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
}

type Step = 'login' | 'signup' | 'otp' | 'profile-setup';

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [step, setStep] = useState<Step>('login');

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginSuccessNotice, setLoginSuccessNotice] = useState('');

  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupError, setSignupError] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);

  // OTP state
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpSuccessNotice, setOtpSuccessNotice] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Profile setup state
  const [profileName, setProfileName] = useState('');
  const [profileAvatar, setProfileAvatar] = useState<string>('');
  const [profileError, setProfileError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown((prev) => prev - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  if (!isOpen) return null;

  // STEP 1: Handle Signup Submit & Dispatch EmailJS OTP
  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError('');

    if (!signupName.trim() || !signupEmail.trim() || !signupPassword) {
      setSignupError('Please fill in all fields.');
      return;
    }

    if (signupPassword.length < 6) {
      setSignupError('Password must be at least 6 characters.');
      return;
    }

    setIsSendingOtp(true);

    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOtp);

    const result = await sendOtpEmail({
      name: signupName.trim(),
      email: signupEmail.trim(),
      passcode: newOtp,
    });

    setIsSendingOtp(false);

    if (result.success) {
      setEnteredOtp('');
      setOtpError('');
      setOtpSuccessNotice(
        `A 6-digit code has been sent to ${signupEmail.trim()}`
      );
      setProfileName(signupName.trim());
      setResendCooldown(30);
      setStep('otp');
    } else {
      setEnteredOtp('');
      setOtpError(
        result.error
          ? `${result.error}. (Code: ${newOtp})`
          : 'Could not send verification email.'
      );
      setProfileName(signupName.trim());
      setStep('otp');
    }
  };

  // STEP 2: Handle Resending OTP
  const handleResendOtp = async () => {
    if (resendCooldown > 0 || isSendingOtp) return;
    setIsSendingOtp(true);
    setOtpError('');

    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOtp);

    const result = await sendOtpEmail({
      name: signupName.trim(),
      email: signupEmail.trim(),
      passcode: newOtp,
    });

    setIsSendingOtp(false);
    setResendCooldown(30);

    if (result.success) {
      setOtpSuccessNotice(`New code sent to ${signupEmail.trim()}`);
    } else {
      setOtpError(`Could not resend: ${result.error || 'Failed'}. (Code: ${newOtp})`);
    }
  };

  // STEP 3: Handle OTP Verification
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError('');

    if (enteredOtp.trim() !== generatedOtp.trim()) {
      setOtpError('Incorrect code. Please enter the 6-digit code sent to your email.');
      return;
    }

    setStep('profile-setup');
  };

  // Handle Photo Upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setProfileError('Please upload an image file (PNG, JPG).');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setProfileError('Image size should be less than 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProfileAvatar(reader.result);
        setProfileError('');
      }
    };
    reader.readAsDataURL(file);
  };

  // STEP 4: Handle Profile Setup Completion
  const handleProfileComplete = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError('');

    if (!profileName.trim()) {
      setProfileError('Please enter your name.');
      return;
    }

    if (!profileAvatar) {
      setProfileError('Please upload a profile photo.');
      return;
    }

    saveUser({
      name: profileName.trim(),
      email: signupEmail.trim(),
      password: signupPassword,
      avatarUrl: profileAvatar,
      createdAt: new Date().toISOString(),
    });

    setLoginEmail(signupEmail.trim());
    setLoginPassword('');
    setLoginError('');
    setLoginSuccessNotice(
      'Profile setup completed! Please login with your email and password.'
    );
    setStep('login');
  };

  // STEP 5: Handle Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginEmail.trim() || !loginPassword) {
      setLoginError('Email and password are required.');
      return;
    }

    const trimmedEmail = loginEmail.trim().toLowerCase();

    // Special Official Admin Credentials
    if (
      trimmedEmail === 'zeptalabs.com@gmail.com' &&
      loginPassword === 'GeometryDashGeode'
    ) {
      onLoginSuccess({
        name: 'ZeptaLabs Officials',
        email: 'zeptalabs.com@gmail.com',
        avatarUrl: 'logo.png',
        isAdmin: true,
        hideEmail: true,
      });
      onClose();
      return;
    }

    const user = findUserByEmail(loginEmail.trim());
    if (!user) {
      setLoginError('No account found with this email. Please sign up first.');
      return;
    }

    if (user.password !== loginPassword) {
      setLoginError('Incorrect password.');
      return;
    }

    onLoginSuccess({
      name: user.name,
      email: user.email,
      avatarUrl: user.avatarUrl,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60"
        />

        {/* Modal Card */}
        <motion.div
          initial={{ scale: 0.94, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.94, opacity: 0, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="relative w-full max-w-md bg-white border border-neutral-300 p-6 sm:p-8 z-10 shadow-xl max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
            <h2 className="text-lg font-bold text-black tracking-tight">
              {step === 'login' && 'Login'}
              {step === 'signup' && 'Create Account'}
              {step === 'otp' && 'Verify Code'}
              {step === 'profile-setup' && 'Profile Setup'}
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="p-1 text-neutral-500 hover:text-black transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* VIEW: LOGIN */}
          {step === 'login' && (
            <div className="mt-6">
              {/* Tab Switcher */}
              <div className="flex border border-neutral-200 p-1 bg-neutral-100 mb-5">
                <button
                  type="button"
                  className="flex-1 py-1.5 text-xs font-semibold uppercase bg-white text-black shadow-xs"
                >
                  Login
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep('signup');
                    setSignupError('');
                    setLoginSuccessNotice('');
                  }}
                  className="flex-1 py-1.5 text-xs font-semibold uppercase text-neutral-600 hover:text-black transition-colors"
                >
                  Sign Up
                </button>
              </div>

              {loginSuccessNotice && (
                <div className="mb-4 p-3 bg-neutral-50 border border-neutral-300 text-xs text-neutral-800 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-black shrink-0 mt-0.5" />
                  <span>{loginSuccessNotice}</span>
                </div>
              )}

              {loginError && (
                <div className="mb-4 p-3 bg-neutral-50 border border-black text-xs text-black flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-black text-white text-sm font-medium py-2.5 hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Login</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-center text-xs text-neutral-500 pt-2">
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setStep('signup');
                      setSignupError('');
                      setLoginSuccessNotice('');
                    }}
                    className="text-black underline font-semibold hover:text-neutral-700"
                  >
                    Sign Up
                  </button>
                </p>
              </form>
            </div>
          )}

          {/* VIEW: SIGNUP */}
          {step === 'signup' && (
            <div className="mt-6">
              {/* Tab Switcher */}
              <div className="flex border border-neutral-200 p-1 bg-neutral-100 mb-5">
                <button
                  type="button"
                  onClick={() => {
                    setStep('login');
                    setLoginError('');
                  }}
                  className="flex-1 py-1.5 text-xs font-semibold uppercase text-neutral-600 hover:text-black transition-colors"
                >
                  Login
                </button>
                <button
                  type="button"
                  className="flex-1 py-1.5 text-xs font-semibold uppercase bg-white text-black shadow-xs"
                >
                  Sign Up
                </button>
              </div>

              {signupError && (
                <div className="mb-4 p-3 bg-neutral-50 border border-black text-xs text-black flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{signupError}</span>
                </div>
              )}

              <form onSubmit={handleSignupSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={signupName}
                    onChange={(e) => setSignupName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black"
                  />
                  <p className="text-[11px] text-neutral-500 mt-1">
                    At least 6 characters.
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isSendingOtp}
                    className="w-full bg-black text-white text-sm font-medium py-2.5 hover:bg-neutral-800 disabled:bg-neutral-600 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isSendingOtp ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Sending Code...</span>
                      </>
                    ) : (
                      <>
                        <span>Create Account</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>

                <p className="text-center text-xs text-neutral-500 pt-2">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      setStep('login');
                      setLoginError('');
                    }}
                    className="text-black underline font-semibold hover:text-neutral-700"
                  >
                    Login
                  </button>
                </p>
              </form>
            </div>
          )}

          {/* VIEW: OTP CODE INTERFACE */}
          {step === 'otp' && (
            <div className="mt-6">
              <div className="text-center mb-5">
                <h3 className="text-base font-semibold text-black">
                  Enter Verification Code
                </h3>
                <p className="text-xs text-neutral-600 mt-1">
                  We sent a 6-digit code to{' '}
                  <span className="font-semibold text-black">{signupEmail}</span>.
                </p>
              </div>

              {otpSuccessNotice && (
                <div className="mb-4 p-3 bg-neutral-50 border border-neutral-300 text-xs text-neutral-800 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-black shrink-0 mt-0.5" />
                  <span>{otpSuccessNotice}</span>
                </div>
              )}

              {otpError && (
                <div className="mb-4 p-3 bg-neutral-50 border border-black text-xs text-black flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{otpError}</span>
                </div>
              )}

              <form onSubmit={handleVerifyOtp} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1 text-center">
                    6-Digit Code
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={enteredOtp}
                    onChange={(e) =>
                      setEnteredOtp(e.target.value.replace(/\D/g, ''))
                    }
                    placeholder="123456"
                    className="w-full text-center text-2xl tracking-widest font-mono py-2.5 border border-neutral-300 bg-white text-black focus:outline-none focus:border-black font-semibold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-black text-white text-sm font-medium py-2.5 hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Verify &amp; Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-between pt-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setStep('signup')}
                    className="text-neutral-500 hover:text-black underline"
                  >
                    Change Email
                  </button>

                  <button
                    type="button"
                    onClick={handleResendOtp}
                    disabled={resendCooldown > 0 || isSendingOtp}
                    className="text-black font-medium hover:text-neutral-700 disabled:text-neutral-400 flex items-center gap-1"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${
                        isSendingOtp ? 'animate-spin' : ''
                      }`}
                    />
                    <span>
                      {resendCooldown > 0
                        ? `Resend in ${resendCooldown}s`
                        : 'Resend Code'}
                    </span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* VIEW: PROFILE SETUP */}
          {step === 'profile-setup' && (
            <div className="mt-6">
              <div className="text-center mb-5">
                <h3 className="text-base font-semibold text-black">
                  Set Up Your Profile
                </h3>
                <p className="text-xs text-neutral-600 mt-1">
                  Add a photo and confirm your name.
                </p>
              </div>

              {profileError && (
                <div className="mb-4 p-3 bg-neutral-50 border border-black text-xs text-black flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{profileError}</span>
                </div>
              )}

              <form onSubmit={handleProfileComplete} className="space-y-5">
                {/* Photo Uploader */}
                <div className="flex flex-col items-center">
                  <div className="relative mb-3">
                    <div className="w-24 h-24 rounded-full border border-neutral-300 overflow-hidden bg-neutral-100 flex items-center justify-center">
                      {profileAvatar ? (
                        <img
                          src={profileAvatar}
                          alt="Profile Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-10 h-10 text-neutral-400" />
                      )}
                    </div>
                  </div>

                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1.5 border border-black text-xs font-medium text-black hover:bg-neutral-100 transition-colors flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{profileAvatar ? 'Change Photo' : 'Upload Photo'}</span>
                    </button>
                    {profileAvatar && (
                      <button
                        type="button"
                        onClick={() => setProfileAvatar('')}
                        className="px-2 py-1.5 text-xs text-neutral-500 hover:text-black"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>

                {/* Name Input */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-3 py-2 border border-neutral-300 bg-white text-black text-sm focus:outline-none focus:border-black font-medium"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-black text-white text-sm font-medium py-2.5 hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Save &amp; Continue to Login</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
