import React, { useState } from 'react';
import { Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  return (
    <section id="contact" className="w-full pt-6 pb-12 border-t border-neutral-200 scroll-mt-20">
      <div className="pb-3 border-b border-neutral-200 mb-6">
        <h2 className="text-2xl font-bold tracking-tight text-neutral-900">
          Contact Us
        </h2>
        <p className="text-sm text-neutral-500 mt-1">
          Have a question or feedback? Send us a message and we will get back to you.
        </p>
      </div>

      {submitted ? (
        <div className="p-8 border border-neutral-200 bg-neutral-50 text-center space-y-3 max-w-lg">
          <CheckCircle2 className="w-8 h-8 mx-auto text-black" />
          <h3 className="text-base font-semibold text-black">Message Sent</h3>
          <p className="text-sm text-neutral-600">
            Thank you for reaching out. We will reply to your email as soon as possible.
          </p>
          <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="mt-2 px-4 py-2 text-xs font-medium border border-black text-black hover:bg-neutral-200 transition-colors cursor-pointer"
          >
            Send Another Message
          </button>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSubmitted(true);
          }}
          className="border border-neutral-200 p-6 sm:p-8 bg-white space-y-4 max-w-lg"
        >
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Your Name
            </label>
            <input
              type="text"
              required
              placeholder="Your name"
              className="w-full px-3 py-2 border border-neutral-300 text-sm text-black focus:outline-none focus:border-black transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              placeholder="your.email@example.com"
              className="w-full px-3 py-2 border border-neutral-300 text-sm text-black focus:outline-none focus:border-black transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Message
            </label>
            <textarea
              rows={4}
              required
              placeholder="How can we help you?"
              className="w-full px-3 py-2 border border-neutral-300 text-sm text-black focus:outline-none focus:border-black transition-colors resize-none"
            />
          </div>

          <button
            type="submit"
            className="inline-flex items-center gap-2 bg-black text-white px-5 py-2.5 text-sm font-medium hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <span>Send Message</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      )}
    </section>
  );
};
