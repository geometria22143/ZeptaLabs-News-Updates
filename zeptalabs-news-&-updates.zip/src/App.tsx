import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { NewsSection } from './components/NewsSection';
import { UpdatesSection } from './components/UpdatesSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { ShareModal } from './components/ShareModal';
import { UserProfile } from './types/auth';
import { PostItem } from './types/post';
import { getCurrentUser, setCurrentUser } from './utils/authStorage';
import { fetchAllPosts } from './utils/postStorage';

export default function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [currentUser, setProfileState] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<PostItem[]>([]);

  useEffect(() => {
    // Restore persistent session
    const saved = getCurrentUser();
    if (saved) {
      setProfileState(saved);
    }
    // Fetch live shared posts from server
    fetchAllPosts().then((loaded) => setPosts(loaded));
  }, []);

  const handleLoginSuccess = (user: UserProfile) => {
    setProfileState(user);
    setCurrentUser(user);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setProfileState(null);
    setCurrentUser(null);
  };

  const handlePostCreated = (newPost: PostItem) => {
    setPosts((prev) => [newPost, ...prev.filter((p) => p.id !== newPost.id)]);
    // Smooth scroll to the relevant section
    const targetSection =
      newPost.category === 'News' ? 'news' : 'updates';
    const el = document.getElementById(targetSection);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePostUpdated = async () => {
    const updated = await fetchAllPosts();
    setPosts(updated);
  };

  return (
    <div className="min-h-screen bg-white text-black font-sans antialiased selection:bg-neutral-200 selection:text-black flex flex-col">
      {/* Website Top Header & Navigation */}
      <Navbar
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        onOpenShareModal={() => setIsShareModalOpen(true)}
      />

      {/* Website Main Page Content */}
      <main className="flex-1 w-full bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
          {/* Section 1: Check Latest News */}
          <NewsSection
            posts={posts}
            onPostUpdated={handlePostUpdated}
            currentUser={currentUser}
          />

          {/* Section 2: Check Updates */}
          <UpdatesSection
            posts={posts}
            onPostUpdated={handlePostUpdated}
            currentUser={currentUser}
          />

          {/* Section 3: About ZeptaLabs */}
          <AboutSection />

          {/* Section 4: Contact Us */}
          <ContactSection />
        </div>
      </main>

      {/* Website Footer */}
      <Footer />

      {/* Login / Signup Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Admin Share An Update/News Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        onPostCreated={handlePostCreated}
      />
    </div>
  );
}
