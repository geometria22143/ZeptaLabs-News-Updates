import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'data', 'posts.json');

// Ensure data directory and file exist
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, '[]', 'utf-8');
}

// Allow generous payload limits for photo/video/apk uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

interface CommentItem {
  id: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  createdAt: string;
  likes: number;
  likedBy: string[];
}

interface PostItem {
  id: string;
  category: 'News' | 'Update';
  title: string;
  description?: string;
  attachment?: {
    name: string;
    type: string;
    dataUrl: string;
    sizeFormatted: string;
  };
  authorName: string;
  authorAvatar: string;
  createdAt: string;
  likes: number;
  likedBy: string[];
  shares: number;
  comments: CommentItem[];
}

function readPosts(): PostItem[] {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function writePosts(posts: PostItem[]): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(posts, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write posts to file:', err);
  }
}

// API Routes
app.get('/api/posts', (_req: Request, res: Response) => {
  const posts = readPosts();
  res.json(posts);
});

app.post('/api/posts', (req: Request, res: Response) => {
  const body = req.body;
  if (!body.title || !body.category) {
    res.status(400).json({ error: 'Title and category are required' });
    return;
  }

  const posts = readPosts();
  const newPost: PostItem = {
    id: 'post_' + Date.now().toString(),
    category: body.category,
    title: body.title,
    description: body.description || undefined,
    attachment: body.attachment || undefined,
    authorName: body.authorName || 'ZeptaLabs Officials',
    authorAvatar: body.authorAvatar || 'logo.png',
    createdAt:
      new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }) +
      ' ' +
      new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    likes: 0,
    likedBy: [],
    shares: 0,
    comments: [],
  };

  posts.unshift(newPost);
  writePosts(posts);
  res.status(201).json(newPost);
});

// Like/Unlike Post
app.post('/api/posts/:id/like', (req: Request, res: Response) => {
  const { id } = req.params;
  const { clientId } = req.body;
  if (!clientId) {
    res.status(400).json({ error: 'clientId is required' });
    return;
  }

  const posts = readPosts();
  let result = { likes: 0, isLiked: false };

  const updated = posts.map((p) => {
    if (p.id === id) {
      const alreadyLiked = (p.likedBy || []).includes(clientId);
      const newLikedBy = alreadyLiked
        ? (p.likedBy || []).filter((cid) => cid !== clientId)
        : [...(p.likedBy || []), clientId];
      result = { likes: newLikedBy.length, isLiked: !alreadyLiked };
      return {
        ...p,
        likes: newLikedBy.length,
        likedBy: newLikedBy,
      };
    }
    return p;
  });

  writePosts(updated);
  res.json(result);
});

// Share Post
app.post('/api/posts/:id/share', (req: Request, res: Response) => {
  const { id } = req.params;
  const posts = readPosts();
  let shares = 0;

  const updated = posts.map((p) => {
    if (p.id === id) {
      shares = (p.shares || 0) + 1;
      return { ...p, shares };
    }
    return p;
  });

  writePosts(updated);
  res.json({ shares });
});

// Add Comment
app.post('/api/posts/:id/comments', (req: Request, res: Response) => {
  const { id } = req.params;
  const { authorName, content, authorAvatar } = req.body;

  if (!content || !content.trim()) {
    res.status(400).json({ error: 'Content is required' });
    return;
  }

  const posts = readPosts();
  let createdComment: CommentItem | null = null;

  const updated = posts.map((p) => {
    if (p.id === id) {
      createdComment = {
        id: 'comment_' + Date.now().toString(),
        authorName: (authorName && authorName.trim()) || 'Visitor',
        authorAvatar: authorAvatar || '',
        content: content.trim(),
        createdAt: 'Just now',
        likes: 0,
        likedBy: [],
      };
      return {
        ...p,
        comments: [...(p.comments || []), createdComment],
      };
    }
    return p;
  });

  writePosts(updated);
  res.status(201).json(createdComment);
});

// Like Comment
app.post('/api/posts/:id/comments/:commentId/like', (req: Request, res: Response) => {
  const { id, commentId } = req.params;
  const { clientId } = req.body;
  if (!clientId) {
    res.status(400).json({ error: 'clientId is required' });
    return;
  }

  const posts = readPosts();
  let result = { likes: 0, isLiked: false };

  const updated = posts.map((p) => {
    if (p.id === id) {
      const updatedComments = (p.comments || []).map((c) => {
        if (c.id === commentId) {
          const alreadyLiked = (c.likedBy || []).includes(clientId);
          const newLikedBy = alreadyLiked
            ? (c.likedBy || []).filter((cid) => cid !== clientId)
            : [...(c.likedBy || []), clientId];
          result = { likes: newLikedBy.length, isLiked: !alreadyLiked };
          return {
            ...c,
            likes: newLikedBy.length,
            likedBy: newLikedBy,
          };
        }
        return c;
      });
      return { ...p, comments: updatedComments };
    }
    return p;
  });

  writePosts(updated);
  res.json(result);
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
